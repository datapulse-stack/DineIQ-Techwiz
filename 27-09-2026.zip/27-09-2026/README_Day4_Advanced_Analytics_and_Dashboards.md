# Day 4: Advanced Analytics and Dashboards

**Project:** DineIQ Analytics | **Goal:** all functional requirements work end to end in the web app.
**Checklist items:** 23, 24, 25, 26, 27, 28, 29, 30, 31, 32

---

## Tasks

- [ ] **Wastage intelligence** [23]
  - Analyze by item, category, location, day, time, demand, inventory, promotion
  - Predict high wastage-risk items or periods
- [ ] **Pricing intelligence** [24]
  - Price vs demand, revenue, margin, discount, rating, repeat purchase
  - Classify items: Highly, Moderately, Low price sensitivity
- [ ] **Promotion analytics** [25]
  - Evaluate volume, revenue, margin, customer acquisition, repeat purchase, AOV, wastage, post-promotion behavior
  - Detect promotion traps (sales up but profit down, wastage up, sales only while discounted, cannibalization)
- [ ] **Rating and sales anomalies** [26]
  - Rating spikes/drops, identical ratings, bursts of ratings
  - Sales spikes/drops, abnormal order values, unusual discounts, duplicate transactions
- [ ] **Multi-location comparison** [27]
  - Revenue, profit, AOV, customers, repeat purchase, wastage, ratings
  - Location-specific Profit Drivers, Volume Drivers, Hidden Opportunities, Low Performers
- [ ] **Ordering channel analysis** [28]
  - Dine-in, takeaway, website/app, delivery: basket size, AOV, preferences, discounts, peaks, profitability
- [ ] **Churn risk and recommendation engine** [29]
  - Identify customers with declining engagement
  - Every recommendation shows its evidence and a priority (Low / Medium / High / Critical)
  - No unexplained recommendations
- [ ] **What-if simulator** [30]
  - Change price, discount, promotion frequency, prep quantity, demand, wastage, remove an item
  - Show impact on revenue, margin, demand, wastage, and label it clearly as an estimate
- [ ] **Dashboards** [31]
  - Executive, Menu Intelligence, Customer Intelligence, Wastage, Forecast, Dual-Pipeline Comparison
  - Show insights and conclusions, not only charts
- [ ] **Search, reports and export** [32]
  - Filters: date, location, item, category, segment, channel, promotion, class, price, rating, wastage
  - Downloadable reports and CSV/Excel export for permitted roles

## End-of-Day Check

- [ ] Each analytics module returns real results from your own logic
- [ ] Every dashboard loads without errors
- [ ] Recommendations show evidence and priority
- [ ] What-if outputs are labelled as estimates
- [ ] Export works and respects role permissions
- [ ] All 4 members have committed today
- [ ] Development log updated

## Development Log: Day 4

| Item | Notes |
|---|---|
| Work completed | |
| Dataset changes | |
| Data-quality problems | |
| Spark failures | |
| Model failures | |
| Changes made | |
| Tests performed | |
| Performance improvements | |
