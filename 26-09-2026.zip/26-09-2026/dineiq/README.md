# DineIQ Analytics — MenuMatrix Dining Intelligence

A big-data / data-science platform that turns raw restaurant transaction data into
menu, customer, wastage, pricing and demand intelligence — and presents it in an
owner-friendly web dashboard.

Built for the *Data Science Intelligence Arena* brief. Everything runs in plain
Python on **CSV** data; there is a PySpark mirror for the Big-Data track.

---

## What it does

- **Generates** a realistic 11-table restaurant dataset (~43k orders, ~117k order-lines)
- **Assesses data quality** and cleans/quarantines bad rows with a full audit log
- **Integrates** the tables into one order-line fact table (Spark-SQL-style joins)
- **Engineers features** at item, customer and daily grain
- **Classifies every dish** into Profit Driver / Volume Driver / Hidden Opportunity /
  Low Performer — data-driven, *not* keyed off any single column
- **Segments customers** with RFM + KMeans
- **Mines the basket** for association rules (support / confidence / lift)
- **Forecasts demand** with a time-aware model (no leakage) and honest MAE/RMSE/MAPE
- **Analyses pricing** (elasticity + sensitivity) and **promotions** (incl. trap detection)
- **Predicts wastage risk** and finds **anomalies** (sales, margin, rating clusters)
- Runs **two independent ML pipelines** and **compares** them (Spark vs Python)
- Produces **evidence-backed, prioritised recommendations** and a **What-If simulator**

The dashboard has 13 views: Executive, Menu, Customers, Wastage, Forecast,
Pricing & Promo, Market Basket, Locations, Dual-Pipeline, Anomalies,
Recommendations, the What-If Lab and Reports & Export — with light/dark themes,
an 11-dimension live filter bar and CSV/Excel export.

---

## Step-by-step setup

No database server and no front-end build step — just Python.

**Prerequisites**
- Python **3.9+** (`python --version` to check)
- `pip` and, recommended, a virtual environment

**1. Get the code and open the folder**
```bash
cd dineiq
```

**2. (Recommended) create & activate a virtual environment**
```bash
python -m venv .venv
# macOS / Linux:
source .venv/bin/activate
# Windows (PowerShell):
.venv\Scripts\Activate.ps1
```

**3. Install the dependencies**
```bash
pip install -r requirements.txt
```

**4. Generate the data and run the full analytics pipeline**
```bash
python run_all.py
```
This writes the raw CSVs to `raw_data/`, the cleaned data + report CSVs to
`processed_data/`, and everything the dashboard renders to
`outputs/dashboard_data.json`. First run takes a minute or two.

**5. Launch the dashboard**
```bash
python app.py
```

**6. Open it in your browser**
```
http://localhost:5000
```
You'll land on the sign-in screen. Log in with the seeded admin (below).

**7. Sign in**
```
email:    admin@dineiq.local
password: admin123
```
Change the password (or create more users) from the **Admin** console in the
top bar.

---

### Handy re-runs
```bash
python run_all.py --skip-gen     # re-run analytics on the existing data (no regen)
python -m data_generator.generate_data   # regenerate the CSVs only
python -m src.pipeline           # run the pipeline only
```

> Nothing to build — the CSS/JS are served as-is. If a page ever looks unstyled,
> hard-refresh (Ctrl/Cmd+Shift+R) to bust the browser cache.

---

## Login, roles & audit trail

The dashboard sits behind authentication (SQLite + hashed passwords).

- **Sign up** is open — anyone can create an account, but new users land on the
  **Analyst** (view-only) role until an admin upgrades them.
- **Roles & permissions** — each role gets a genuinely different app, not just a
  different label. The sidebar shows a live "role access" card that ticks/greys-out
  exactly what you can do, and the navigation itself changes per role:

  | Capability                      | Analyst | Manager | Admin |
  |---------------------------------|:-------:|:-------:|:-----:|
  | View all 11 analytics boards    |   ✓     |   ✓     |   ✓   |
  | Download reports (CSV / Excel)  |   ✕     |   ✓     |   ✓   |
  | What-If planning lab            |   ✕     |   ✓     |   ✓   |
  | Admin console & audit log       |   ✕     |   ✕     |   ✓   |

  What that means in practice:
  - **Analyst** — read-only. No Export button in the top bar, the *What-If Lab*
    is hidden from the sidebar entirely, and every `/download/*` route returns
    **403**. They analyse; they don't change or extract.
  - **Manager** — everything an Analyst sees **plus** the Export button, the
    What-If planning lab, and CSV/Excel downloads on every report.
  - **Admin** — everything a Manager has **plus** the Admin console (create users,
    change roles, read the full audit trail).

  Enforcement is server-side (`auth.PERMISSIONS` + the `@require` decorator), so
  hiding a button in the UI is backed by a real 403 on the route — a curious
  Analyst can't just call the download URL directly.
- **Audit trail** — logins, failed logins, signups, exports and admin actions are
  all recorded (who / what / when / IP) and shown in the admin console.

First run auto-seeds an admin so you can get in:

```
email:    admin@dineiq.local
password: admin123      (change it from the admin console)
```

The users database (`database/dineiq.db`) and the session key are git-ignored so
they never end up in your repo.

## The dataset (scale)

The generator builds its own realistic, interconnected dataset that clears every
SRS minimum. A fresh `python run_all.py` produces:

| Table            | Rows        | SRS minimum |
|------------------|-------------|-------------|
| Order-lines      | ~1,209,000  | 1,000,000   |
| Orders           | ~312,500    | 100,000     |
| Customers        | 52,000      | 50,000      |
| Menu items       | 150         | 150         |
| Menu categories  | 10          | 10          |
| Locations        | 20          | 20          |
| Ratings          | ~157,000    | 100,000     |
| Wastage records  | ~153,000    | 50,000      |
| Price history    | ~600        | multiple    |
| Promotions       | 9           | multiple    |
| History window   | 365 days    | 12 months   |

Generation is fully vectorised (numpy), so building ~1.2M interconnected rows
takes ~10 seconds; the whole `run_all.py` (generate + analyse) is under a minute.
Raw CSVs land in `raw_data/` (~87 MB total).

> Tune the volume in `src/config.py` — `N_CUSTOMERS`, `ORDERS_PER_CELL` and
> `BASKET_LAMBDA` drive the row counts; the menu, categories, locations and
> promotions are all edit-in-one-place lists.

## Search & filtering (step 48)

The **Filters** button in the top bar opens a filter bar covering all eleven
required dimensions: date range, location, menu item, menu category, customer
segment, ordering channel, promotion, performance class, price range, rating and
wastage range. Filtering is **hybrid**:

- **Server-side recompute** — Apply posts to `/api/filter`, which slices the
  cached ~1.2M-row fact table and recomputes the KPIs, revenue trend, category
  mix, menu table, location table, channel mix and segment mix (sub-second).
- **Client-side** — tables filter/sort instantly in the browser.

A result chip shows exactly how many orders / lines / customers / items matched,
and Reset restores the full view. (The model/forecast/basket views stay on the
full dataset, since those are trained model outputs.)

## Reports & export (steps 49 + 50)

The **Reports & Export** tab lists all twelve reports; each downloads as **CSV**
or **Excel (.xlsx)**:

Menu performance · Profitability · Customer segmentation · Market-basket
analysis · Demand forecast · Wastage · Promotions · Pricing · Location
performance · Anomalies · Recommendations · Spark vs Python model comparison.

Export requires the **export** permission (Manager/Admin) — Analysts get a
view-only catalogue and the server returns `403` on any download attempt. Every
export is written to the audit log (who / what / format / when / IP). The CSVs
also live in `processed_data/` if you want them straight off disk.

**View-in-browser (every role).** Each report also has a **View** button that
opens the data in an Excel-style table right on the dashboard — sticky headers,
frozen row numbers, zebra striping. Reading data isn't the same as exporting it,
so **Analysts can open and read every report** even though they can't download.
Backed by `GET /api/report/<key>` (login required, capped at 2,000 rows).

## More on the app

- **Home page.** After login you land on a **Home** board — a welcome hero with
  the headline metrics (revenue, profit, orders, AOV), the revenue trend, top
  items and locations, the category split, critical alerts, and quick-jump tiles
  into all 13 boards. Everything important, up front.
- **Data assistant (chatbot).** A floating assistant (bottom-right) answers
  questions about your live numbers — "total revenue", "top item", "how bad is
  wastage", "best location", "what should I do" — via `POST /api/chat`. It's a
  transparent, rule-based responder that reads the computed dashboard data (no
  external service), so it always quotes real figures.
- **Forgot password.** The sign-in page has a **Forgot your password?** link. Any
  role (Admin / Manager / Analyst) can reset their own password from `/forgot`
  (self-service for the demo; a production build would email a one-time link).
  Resets are audit-logged.
- **About page.** The **Data Pulse** wordmark under the logo (renamed from
  "MenuMatrix Intelligence", set in an elegant serif with an animated pulse dot)
  is clickable and opens a polished **About** page describing the platform.

## Project layout

```
dineiq/
├── run_all.py                 one command: generate data + run pipeline
├── app.py                     Flask dashboard + auth (serves computed results)
├── auth.py                    users, roles, audit trail (SQLite)
├── database/                  dineiq.db + session key (git-ignored, auto-created)
├── requirements.txt
├── data_generator/
│   └── generate_data.py       builds the 11 CSV tables
├── raw_data/                  generated raw CSVs
├── processed_data/            cleaned data + downloadable report CSVs
├── outputs/
│   └── dashboard_data.json    everything the dashboard renders
├── src/
│   ├── config.py              paths, menu, thresholds (edit these for surprise mods)
│   ├── data_quality.py        find issues -> data_quality_report.csv
│   ├── clean.py               fix/quarantine -> cleaning_log.csv
│   ├── integrate.py           joins -> order-line fact table
│   ├── features.py            item / customer / daily features
│   ├── menu_classify.py       the 4-quadrant classifier
│   ├── segmentation.py        RFM + KMeans
│   ├── market_basket.py       association rules
│   ├── forecast.py            time-aware demand forecast
│   ├── pricing.py             elasticity + sensitivity
│   ├── promotions.py          effectiveness + trap detection
│   ├── wastage.py             wastage analysis + risk
│   ├── anomaly.py             anomaly + rating-cluster detection
│   ├── recommend.py           evidence-backed recommendations
│   ├── models.py              dual-pipeline training + comparison
│   ├── live.py                live filter engine (server-side recompute)
│   └── pipeline.py            orchestrates everything
├── spark_jobs/
│   └── spark_pipeline.py      PySpark mirror (Big-Data track, optional)
├── templates/                 dashboard, login, signup, admin, 403 + _scene.html partial
└── static/
    ├── style.css              styling: sky/green light theme + cinematic dark, glass, scene
    ├── dashboard.js           renders window.DINEIQ (hand-drawn SVG charts)
    ├── fx.js                  custom cursor, ember/steam particles, button ripples
    └── scene/                 restaurant ambience photos (dark + light) for the animated backdrop
```

---

## Look & feel

- **Two themes, one toggle.** A soft **sky-blue / teal-green** light theme and a
  **cinematic teal-night** dark theme. Pages default to dark so the background
  scene reads well; the toggle in the top bar switches instantly.
- **Small, consistent icons.** All inline glyphs share an `.ico` size so nothing
  overpowers the numbers (charts are drawn separately and unaffected).
- **Animated custom cursor.** A glowing dot with a trailing ring that swells over
  anything clickable. Falls back to the normal cursor on touch devices.
- **Classy motion.** Cards fade/slide in with a subtle stagger, KPIs count into
  focus, buttons lift and ripple, rows and nav react on hover — tuned to feel
  premium, not busy. All of it respects `prefers-reduced-motion`.
- **The background ambience.** A cinematic, restaurant-themed backdrop — a
  candle-lit fine-dining room in dark mode, a bright airy dining space in light
  mode — with a slow **ken-burns** drift, a soft moving light sweep, warm bokeh
  orbs floating up like candle light and gentle kitchen steam. The effect reads
  like quiet video, not a static picture. Behind the dashboard it's blurred and
  dimmed under a readability veil so every chart and number stays razor-sharp,
  and the whole thing honours `prefers-reduced-motion` (the still photo remains,
  the motion stops). Both theme photos live in `static/scene/` and are served by
  Flask, so they load in the browser without any external CDN.

---

## The two pipelines (dual-track)

The brief requires two **independent** pipelines whose results are compared.

- **Python DS pipeline** — `src/` (pandas + scikit-learn). This is the reference
  implementation the dashboard uses. It trains multiple model families and picks
  the best by macro-F1.
- **Big-Data pipeline** — `spark_jobs/spark_pipeline.py` (PySpark + Spark SQL +
  Spark MLlib). Reads the same CSVs, solves the classification independently and
  writes `processed_data/spark_predictions.csv`.

They never share predictions. The comparison view reports agreement, disagreement
and where/why the two diverge. If Spark isn't installed, `src/models.py` trains a
second, differently-configured Python family as an honest stand-in for the
comparison (documented so nothing is hidden).

## Design notes

- The menu classifier scores **demand and profitability relative to the whole
  menu**, then knocks profitability down for wastage and weak ratings before
  bucketing. High sales alone never make a dish a "winner".
- The class label is **location-specific**: the same dish can be a Profit Driver
  at a busy branch and a Low Performer at a quiet one.
- Forecasting trains only on earlier days and validates on a held-out later
  window, and is benchmarked against a simple baseline to prove it adds value.
- Every recommendation carries its supporting evidence. There is **no external
  generative-AI decision API** in the analytics path.

## Extending it

Swap the CSV loaders in `src/pipeline.py` for your POS export (same schema) and
everything downstream just works. Thresholds, the menu and locations live in
`src/config.py` so common changes are one-liners.
