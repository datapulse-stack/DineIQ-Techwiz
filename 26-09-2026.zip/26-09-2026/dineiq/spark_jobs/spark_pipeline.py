"""
PySpark mirror of the core DineIQ pipeline (Big Data track).

This is the Apache Spark side of the dual-pipeline requirement. It reads the same
raw CSVs, does schema-defined ingestion, Spark SQL joins, feature aggregation and
a Spark MLlib classifier, then writes its predictions to
    processed_data/spark_predictions.csv
which the Python comparator (src/models.py) will prefer over its stand-in when
present.

It is intentionally kept separate from the pandas pipeline so the two solve the
problem INDEPENDENTLY (no sharing of predictions), which is what the SRS asks for.

Run (only where a JVM + Spark are installed):
    pip install pyspark
    python spark_jobs/spark_pipeline.py

If PySpark isn't installed this file simply won't run - the pandas pipeline in
src/ is the reference implementation used by the dashboard in that case.
"""
import os
import sys

try:
    from pyspark.sql import SparkSession, functions as F
    from pyspark.sql.types import (StructType, StructField, StringType,
                                   IntegerType, DoubleType, TimestampType)
    from pyspark.ml.feature import VectorAssembler, StringIndexer, StandardScaler
    from pyspark.ml.classification import RandomForestClassifier
    from pyspark.ml import Pipeline
    from pyspark.ml.evaluation import MulticlassClassificationEvaluator
except ImportError:
    print("PySpark is not installed. Install it with `pip install pyspark` to run "
          "the Big Data pipeline. The pandas pipeline in src/ is the fallback.")
    sys.exit(0)

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
RAW = os.path.join(ROOT, "raw_data")
PROCESSED = os.path.join(ROOT, "processed_data")


def main():
    spark = (SparkSession.builder
             .appName("DineIQ-BigData")
             .master("local[*]")
             .config("spark.sql.shuffle.partitions", "8")
             .getOrCreate())

    # ---- explicit schema (SRS: demonstrate schema definition, not just inference)
    oi_schema = StructType([
        StructField("order_item_id", StringType(), False),
        StructField("order_id", StringType(), False),
        StructField("item_id", StringType(), True),
        StructField("quantity", IntegerType(), True),
        StructField("unit_price", DoubleType(), True),
        StructField("discount_pct", DoubleType(), True),
        StructField("line_total", DoubleType(), True),
    ])

    orders = spark.read.csv(f"{RAW}/orders.csv", header=True, inferSchema=True)
    oitems = spark.read.csv(f"{RAW}/order_items.csv", header=True, schema=oi_schema)
    items = spark.read.csv(f"{RAW}/menu_items.csv", header=True, inferSchema=True)
    inventory = spark.read.csv(f"{RAW}/inventory.csv", header=True, inferSchema=True)

    # ---- basic cleaning (mirror of the pandas rules) ----
    oitems = (oitems.dropDuplicates()
              .filter(F.col("quantity") > 0)
              .filter(F.col("unit_price") > 0))

    # ---- Spark SQL integration ----
    oitems.createOrReplaceTempView("oi")
    orders.createOrReplaceTempView("o")
    items.createOrReplaceTempView("mi")
    fact = spark.sql("""
        SELECT oi.item_id, o.location_id,
               oi.quantity, oi.line_total AS revenue,
               (oi.quantity * mi.food_cost) AS cost,
               mi.base_price, mi.food_cost,
               CASE WHEN o.promotion_id IS NOT NULL AND o.promotion_id <> '' THEN 1 ELSE 0 END AS has_promo
        FROM oi
        JOIN o  ON oi.order_id = o.order_id
        JOIN mi ON oi.item_id  = mi.item_id
        WHERE o.status = 'completed'
    """)

    # ---- feature aggregation per item x location ----
    agg = (fact.groupBy("item_id", "location_id")
           .agg(F.sum("quantity").alias("qty"),
                F.sum("revenue").alias("revenue"),
                F.sum("cost").alias("cost"),
                F.avg("has_promo").alias("promo_dep"),
                F.first("base_price").alias("price"),
                F.first("food_cost").alias("food_cost")))
    agg = agg.withColumn("margin", (F.col("revenue") - F.col("cost")) / F.col("revenue"))

    # ---- label: location-relative demand/profit quadrant (same rule as pandas) ----
    from pyspark.sql.window import Window
    w = Window.partitionBy("location_id")
    agg = (agg
           .withColumn("qmin", F.min("qty").over(w)).withColumn("qmax", F.max("qty").over(w))
           .withColumn("mmin", F.min("margin").over(w)).withColumn("mmax", F.max("margin").over(w)))
    agg = (agg
           .withColumn("demand", (F.col("qty") - F.col("qmin")) / (F.col("qmax") - F.col("qmin")))
           .withColumn("profit", (F.col("margin") - F.col("mmin")) / (F.col("mmax") - F.col("mmin"))))
    agg = agg.withColumn("klass", F.when((F.col("demand") >= 0.55) & (F.col("profit") >= 0.45), "Profit Driver")
             .when((F.col("demand") >= 0.55) & (F.col("profit") < 0.45), "Volume Driver")
             .when((F.col("demand") < 0.55) & (F.col("profit") >= 0.45), "Hidden Opportunity")
             .otherwise("Low Performer"))
    agg = agg.na.fill(0)

    # ---- Spark MLlib model ----
    label_idx = StringIndexer(inputCol="klass", outputCol="label")
    assembler = VectorAssembler(
        inputCols=["qty", "revenue", "margin", "promo_dep", "price", "food_cost"],
        outputCol="features_raw")
    scaler = StandardScaler(inputCol="features_raw", outputCol="features")
    rf = RandomForestClassifier(numTrees=200, seed=42)
    pipe = Pipeline(stages=[label_idx, assembler, scaler, rf])

    train, test = agg.randomSplit([0.7, 0.3], seed=42)
    model = pipe.fit(train)
    pred = model.transform(test)
    acc = MulticlassClassificationEvaluator(metricName="accuracy").evaluate(pred)
    f1 = MulticlassClassificationEvaluator(metricName="f1").evaluate(pred)
    print(f"[Spark] RandomForest  accuracy={acc:.3f}  f1={f1:.3f}")

    # write predictions for the comparator
    out = model.transform(agg).select("item_id", "location_id", "klass",
                                      F.col("prediction").alias("pred_idx"))
    out.toPandas().to_csv(f"{PROCESSED}/spark_predictions.csv", index=False)
    print(f"[Spark] wrote {PROCESSED}/spark_predictions.csv")

    spark.stop()


if __name__ == "__main__":
    main()
