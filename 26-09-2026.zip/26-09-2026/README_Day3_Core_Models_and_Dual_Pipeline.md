# Day 3: Core Models and Dual Pipeline

**Project:** DineIQ Analytics | **Goal:** classification and forecasting work in both Spark and Python.
**Checklist items:** 12, 13, 14, 15, 16, 17, 18, 19, 21, 22, 40, 47, 48

---

## Tasks

- [ ] **Menu classification** [12]
  - Profit Driver, Volume Driver, Hidden Opportunity, Low Performer
  - Must be data-driven, not based on a single hardcoded field
- [ ] **Tricky cases** [13]
  - High-selling loss-making dish, profitable but rarely purchased dish
  - Popular dish with high wastage, highly rated dish with poor profit
  - Promotion-dependent dish, seasonal item, weekend-only item, new item with little history
- [ ] **Spark MLlib models** [14]
  - Train and compare at least 3 algorithms (for example, Logistic Regression, Random Forest, GBT)
  - Use train / validation / test splits
  - Select the final model by evaluation metrics
- [ ] **Independent Python pipeline** [15]
  - Pandas, Scikit-learn, XGBoost on the same underlying records
  - Do not reuse Spark predictions
- [ ] **Dual-pipeline comparison** [16]
  - Record ID, actual value, Spark result, Python result, match/mismatch, numerical difference, explanation of disagreement, agreement %
- [ ] **RFM analysis and customer segmentation** [17, 18]
  - Recency, Frequency, Monetary per customer
  - Segments: High-Value Loyal, Frequent, Promotion-Driven, At-Risk, New, Occasional
- [ ] **Market-basket analysis** [19]
  - Support, confidence, lift
  - Bundle, cross-sell and upsell recommendations backed by rule evidence
- [ ] **Demand forecasting** [21, 22]
  - Forecast items, categories, locations, with configurable periods
  - Chronological split only (train on earlier data, test on later data), no leakage
  - Evaluate with MAE, RMSE, MAPE, R² and compare against a simple baseline
- [ ] **Prove independence of the two pipelines** [40]
  - Separate scripts, separate preprocessing, separate training, no copy-paste of results
- [ ] **Collect model evidence** [47, 48]
  - Features, algorithms, hyperparameters, train/val/test results, metrics, confusion matrix, saved models with version, sample predictions

## Targets

- Classification: at least 85% accuracy or macro F1 of at least 0.80
- Forecast: must beat a simple baseline

## End-of-Day Check

- [ ] 3+ Spark MLlib models compared and one selected
- [ ] Python models trained independently
- [ ] Comparison table exists with agreement %
- [ ] Forecast metrics beat the baseline
- [ ] Models saved with version numbers
- [ ] All 4 members have committed today
- [ ] Development log updated

## Development Log: Day 3

| Item | Notes |
|---|---|
| Work completed | |
| Dataset changes | |
| Data-quality problems | |
| Spark failures | |
| Model failures | |
| Changes made | |
| Tests performed | |
| Performance improvements | |
